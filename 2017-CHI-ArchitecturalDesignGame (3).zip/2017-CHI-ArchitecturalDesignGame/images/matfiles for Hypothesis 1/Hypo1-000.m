x=linspace(1,15,15);
y=[11.4345,10.527,10.461,8.2335,8.2005,7.227,7.3755,6.765,7.2765,6.996,4.554,5.478,5.973,4.785,5.016];
figure
scatter(x,y);
hold on 
p = polyfit(x,y,2);
y1 = polyval(p,x);
plot(x,y1);
xlabel('GamePlay Occurences of User ID 5');
ylabel('Total Evacuation Time');
title('Graph of Evacuation Times for different Gameplays of a User ');
text(6,10,'LOS = A, LOA = Low, LOH = Low');