The heatmap names are in the below format

<order number>_Current_Best_Time_<Best evacuation time at that moment>_ID_<User ID>

The order numbers are in increasing order of occurence of user gameplay. 
So lower order number means that user play happened earlier than the one with higher order number.



